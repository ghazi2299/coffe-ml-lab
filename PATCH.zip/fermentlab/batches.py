"""Turn sensor logs + an optional cupping file into batches and scores for Mode 2.

Sensor logs use the same format as Mode 1. The cupping file is separate:

    session,score               session = 1, 2, 3 ... in time order
    session,start,end,score     optional windows, if batches are not separated by time gaps

Outcomes (reported in `info['kind']`):
    real       >= MIN_BATCHES real batches matched to scores from the cupping file
    pseudo     fewer than MIN_BATCHES real batches -> runs are cut into pseudo batches, random scores
    random     enough real batches but no usable cupping scores -> random scores
"""
import io

import numpy as np
import pandas as pd

from . import config as C
from . import data as D

MIN_BATCHES = 6
TARGET_PSEUDO = 8
MIN_PSEUDO_HOURS = 4.0


def read_cupping(raw):
    """Parse the cupping file. Returns None when empty / unreadable, else a DataFrame (session, score[, start, end])."""
    if not raw:
        return None
    try:
        t = pd.read_csv(io.BytesIO(raw))
    except Exception:
        return None
    t.columns = [str(c).strip().lower().lstrip('\ufeff') for c in t.columns]
    if 'session' not in t.columns or 'score' not in t.columns:
        return None
    t['session'] = t['session'].astype(str).str.strip()
    t['score'] = pd.to_numeric(t['score'], errors='coerce')
    return t.dropna(subset=['session'])


def cupping_problem(raw):
    """Human-readable reason when a cupping file was given but cannot be used; None when fine or absent."""
    if not raw:
        return None
    try:
        t = pd.read_csv(io.BytesIO(raw))
    except Exception:
        return 'The cupping file could not be read as a CSV file.'
    cols = {str(c).strip().lower().lstrip('\ufeff') for c in t.columns}
    miss = [c for c in ('session', 'score') if c not in cols]
    if miss:
        return ('The cupping file is missing the column(s): ' + ', '.join(miss) +
                '. It needs at least session,score (one row per batch).')
    return None


def renumber(runs):
    return {str(i + 1): g for i, g in enumerate(runs.values())}


def pseudo_split(runs, target=TARGET_PSEUDO):
    """Cut every run into contiguous pieces so that there are about `target` pseudo batches in total."""
    per = int(np.ceil(target / max(len(runs), 1)))
    out = {}
    for g in runs.values():
        hours = (g.index[-1] - g.index[0]).total_seconds() / 3600.0
        k = max(1, min(per, int(hours // MIN_PSEUDO_HOURS)))
        for part in np.array_split(np.arange(len(g)), k):
            if len(part) >= 4:
                out[str(len(out) + 1)] = g.iloc[part]
    if len(out) < MIN_BATCHES:
        total = sum((g.index[-1] - g.index[0]).total_seconds() for g in runs.values()) / 3600.0
        raise D.DataError(f'The data is too short to build {MIN_BATCHES} test batches ({total:.0f} h found, '
                          f'about {MIN_BATCHES * MIN_PSEUDO_HOURS:.0f} h needed).')
    return out


def windows_table(runs, scores):
    return pd.DataFrame([{'session': k, 'start': str(g.index[0]), 'end': str(g.index[-1]),
                          'hours': round((g.index[-1] - g.index[0]).total_seconds() / 3600.0, 1),
                          'score': round(float(scores.get(k)), 1) if k in scores.index else ''}
                         for k, g in runs.items()])


def resolve(df, cup_raw, step_min, seed=0):
    """Return (runs, scores, info). `df` is the cleaned sensor log (same loader as Mode 1)."""
    cup = read_cupping(cup_raw)
    notes = []
    has_windows = cup is not None and {'start', 'end'} <= set(cup.columns)
    if has_windows:
        try:
            runs = D.prepare_runs(df, step_min, windows=cup[['session', 'start', 'end']])
        except Exception:
            runs = D.prepare_runs(df, step_min)
            has_windows = False
            notes.append('The start and end times in the cupping file did not match the sensor logs, so batches '
                         'were split by time gaps instead.')
    else:
        runs = renumber(D.prepare_runs(df, step_min))
    n_real = len(runs)

    scores, kind = None, None
    if cup is not None:
        s = cup.dropna(subset=['score']).drop_duplicates('session', keep='last')
        s = pd.Series(s['score'].astype(float).values, index=s['session'].values)
        matched = [k for k in runs if k in s.index]
        if len(matched) >= MIN_BATCHES:
            scores, kind = s.loc[matched], 'real'
            runs = {k: runs[k] for k in matched}
            if len(matched) < n_real:
                notes.append(f'{n_real - len(matched)} of {n_real} batches have no score in the cupping file and were left out.')
        else:
            notes.append(f'The cupping file matched {len(matched)} of {n_real} detected batches. At least '
                         f'{MIN_BATCHES} scored batches are needed for real training.')

    if kind is None:
        rng = np.random.default_rng(seed)
        if n_real >= MIN_BATCHES:
            kind = 'random'
            notes.insert(0, f'{n_real} batches were detected, but no usable cupping scores were provided.')
        else:
            kind = 'pseudo'
            if cup is None:
                notes.insert(0, 'No cupping file was provided.')
            runs = pseudo_split(runs)
            notes.append(f'Only {n_real} real batches found, so the data was split into {len(runs)} pseudo batches '
                         f'(consecutive time slices).')
        scores = pd.Series(rng.uniform(70, 88, len(runs)).round(1), index=list(runs))
        notes.append('Scores are random and for testing only. Metrics are not meaningful.')

    info = {'kind': kind, 'notes': notes, 'n_real_batches': n_real, 'n_used': len(runs),
            'windows_defined': bool(has_windows)}
    return runs, scores, info
