(() => {
const $ = s => document.querySelector(s);
const NAME = {ph: 'pH', co2: 'CO₂', o2: 'O₂', temp_process: 'Process temperature', pressure: 'Pressure', temp_scd: 'Chamber temperature (SCD)', rh_scd: 'Humidity (SCD)', temp_sht: 'Temperature (SHT)', rh_sht: 'Humidity (SHT)'};
const UNIT = {ph: '', co2: 'ppm', o2: '%', temp_process: '°C', pressure: 'bar', temp_scd: '°C', rh_scd: '%', temp_sht: '°C', rh_sht: '%'};
const BASE = ['Persistence', 'RollingMean12'];
let mode = null, src = 'upload', files = [], R = {}, cur = 'ph', timer = null, SET = null;

setTimeout(() => $('#splash').classList.add('out'), 3400);
$('#splash').addEventListener('click', () => $('#splash').classList.add('out'));


let SERVE = false, QUIET = false;
const fmtMin = m => { const h = Math.floor(m / 60), r = m % 60; return h ? `${h} h${r ? ' ' + r + ' min' : ''}` : `${r} min`; };
const num = (c, v) => v.toFixed(c === 'co2' ? 0 : c === 'pressure' ? 3 : 2);
const pct = v => `${v >= 0 ? '+' : ''}${(v * 100).toFixed(1)}%`;
const ACR = {mae: 'MAE', rmse: 'RMSE', nmae: 'nMAE', r2: 'R²', ph: 'pH', co2: 'CO₂', o2: 'O₂', rh: 'RH', scd: 'SCD', sht: 'SHT', cv: 'CV', acc: 'Accuracy', persist: 'Persistence', oof: 'Out-of-Fold', h: 'h'};
const HEAD = {horizon_min: 'Horizon (min)', Horizon_min: 'Horizon (min)', Skill_persist: 'Skill vs Persistence', Skill_roll: 'Skill vs Rolling Mean', Skill_Versus_Naive: 'Skill vs Naive', Skill_persist_median: 'Median Skill vs Persistence', R2_delta: 'R² (Change)', Corr: 'Correlation', Cells_beat_persist: 'Forecasts Beating Naive', Acc_good: 'Accuracy', Acc_good_std: 'Accuracy Std', F1_good: 'F1 (Acceptable)', F1_good_std: 'F1 Std', MAE_std: 'MAE Std', RMSE_std: 'RMSE Std', R2_std: 'R² Std', Spearman_std: 'Spearman Std', abs_error: 'Abs Error', error_pct: 'Error (%)', Model_gap: 'Model Gap', skill_vs_persistence: 'Skill vs Persistence', persistence_MAE: 'Persistence MAE', max_abs_error: 'Max Abs Error', min_24h: 'Min (24 h)', max_24h: 'Max (24 h)', mean_24h: 'Mean (24 h)', train_windows: 'Train Windows', test_windows: 'Test Windows', predicted_acceptable: 'Predicted Acceptable', predicted_below: 'Predicted Below Standard'};
const PCT = new Set(['Skill_persist', 'Skill_roll', 'Skill_persist_median', 'Skill_Versus_Naive', 'Cells_beat_persist', 'Acc_good', 'Acc_good_std', 'accuracy', 'skill_vs_persistence']);
const SIGNED = new Set(['Skill_persist', 'Skill_roll', 'Skill_persist_median', 'Skill_Versus_Naive', 'skill_vs_persistence']);
const head = k => HEAD[k] || String(k).replace(/[|]/g, ' ').split(/[_\s]+/).filter(Boolean).map(w => ACR[w.toLowerCase()] || (w[0].toUpperCase() + w.slice(1))).join(' ');
const esc = s => String(s ?? '').replace(/[&<>"]/g, c => ({'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;'}[c]));
const isNum = v => typeof v === 'number' && Number.isFinite(v);
const CSVS = {};
let csvN = 0;
function colFmt(rows, k, pctAll) {
  const vals = rows.map(r => r[k]).filter(v => v !== null && v !== undefined && v !== '');
  if (!vals.length || !vals.every(isNum)) return null;
  if (pctAll || PCT.has(k)) return v => `${SIGNED.has(k) || pctAll ? (v > 0 ? '+' : '') : ''}${(v * 100).toFixed(1)}%`;
  if (vals.every(Number.isInteger)) return v => String(v);
  const mx = Math.max(...vals.map(Math.abs)), d = mx >= 100 ? 2 : mx >= 0.1 ? 3 : 4;
  return v => v.toFixed(d);
}
function tbl(rows, o = {}) {
  if (!rows || !rows.length) return '<p class="mu">No data available.</p>';
  const keys = Object.keys(rows[0]), fm = {}, best = {};
  keys.forEach(k => {
    fm[k] = colFmt(rows, k, o.pct);
    if (o.best && fm[k]) { const v = rows.map(r => r[k]).filter(isNum); best[k] = o.best === 'min' ? Math.min(...v) : Math.max(...v); }
  });
  const td = (r, k) => {
    const v = r[k];
    if (v === null || v === undefined) return '<td class="n">—</td>';
    if (isNum(v) && fm[k]) {
      const c = ['n', best[k] === v ? 'lo' : '', SIGNED.has(k) || o.pct ? (v >= 0 ? 'pos' : 'neg') : ''].filter(Boolean).join(' ');
      return `<td class="${c}">${fm[k](v)}</td>`;
    }
    return `<td>${esc(NAME[v] ?? v)}</td>`;
  };
  let csv = '';
  if (o.csv) { const id = 'c' + (++csvN); CSVS[id] = {name: o.csv, rows: o.all || rows}; csv = `<button class="lb alt sm" data-csv="${id}">Download CSV</button>`; }
  const tall = rows.length > 12;
  return `<div class="sc${tall ? ' tall' : ''}"><table class="ltb"><thead><tr>${keys.map(k => `<th class="${fm[k] ? 'n' : ''}">${esc(head(k))}</th>`).join('')}</tr></thead><tbody>${rows.map(r => `<tr>${keys.map(k => td(r, k)).join('')}</tr>`).join('')}</tbody></table></div>${tall || csv ? `<div class="tfoot"><span>${rows.length} rows</span>${csv}</div>` : ''}`;
}
document.addEventListener('click', ev => {
  const b = ev.target.closest && ev.target.closest('[data-csv]');
  if (!b || !CSVS[b.dataset.csv]) return;
  const c = CSVS[b.dataset.csv], rows = typeof c.rows === 'function' ? c.rows() : c.rows;
  if (!rows.length) return;
  const keys = Object.keys(rows[0]), q = v => v === null || v === undefined ? '' : /[",\n]/.test(String(v)) ? `"${String(v).replace(/"/g, '""')}"` : v;
  const txt = [keys.join(',')].concat(rows.map(r => keys.map(k => q(r[k])).join(','))).join('\n');
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([txt], {type: 'text/csv'}));
  a.download = c.name;
  a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 2000);
});

function openMode(m, scroll) {
  mode = m;
  document.querySelectorAll('.mode').forEach(x => x.classList.toggle('on', +x.dataset.m === m));
  $('#data').hidden = false;
  $('#dataHint').textContent = m === 1 ? 'Mode 1 needs sensor logs only.' : 'Mode 2 needs sensor logs and an optional cupping file.';
  $('#tphRow').hidden = m !== 1;
  setSrc(src);
  renderAdv();
  if (R[m]) {
    const q = QUIET;
    QUIET = true;
    m === 1 ? render1() : render2();
    QUIET = q;
  }
  if (scroll) $('#data').scrollIntoView({behavior: 'smooth', block: 'start'});
}
document.querySelectorAll('.mode').forEach(b => b.addEventListener('click', () => {
  if (SERVE) { serveShow(+b.dataset.m); return; }
  openMode(+b.dataset.m, true);
}));

function setSrc(s) {
  src = s;
  document.querySelectorAll('.src button').forEach(b => b.classList.toggle('on', b.dataset.s === s));
  ['api', 'upload', 'sample', 'model'].forEach(k => { $('#s_' + k).hidden = k !== s; });
  $('#cupBox').hidden = !(mode === 2 && s === 'upload');
  $('#goBtn').disabled = s === 'api' || s === 'model';
  if (s === 'model' && mode) loadSaved();
}
async function loadSaved() {
  const name = kindOf(), box = $('#s_model');
  const s = await (await fetch(`/api/lab/status/${name}`)).json();
  if (s.state !== 'done' || !s.result) { box.textContent = 'No saved results for this mode yet.'; return; }
  box.textContent = 'Showing results from the saved model.';
  R[mode] = s.result;
  mode === 1 ? render1() : render2();
}
async function serveShow(m) {
  mode = m;
  document.querySelectorAll('.mode').forEach(x => x.classList.toggle('on', +x.dataset.m === m));
  ['#out1', '#out2', '#mergeOut'].forEach(i => { $(i).hidden = true; });
  $('#data').hidden = m !== 1;
  $('#tphRow').hidden = m !== 1;
  $('#noSaved').hidden = !!R[m];
  if (R[m]) m === 1 ? render1() : render2();
}
fetch('/api/lab/saved').then(r => r.json()).then(async v => {
  if (!v.forecast && !v.cupping) return;
  for (const [m, k] of [[1, 'forecast'], [2, 'cupping']]) {
    const s = await (await fetch(`/api/lab/status/${k}`)).json();
    if (s.state === 'done' && s.result) R[m] = s.result;
  }
  if (!SET) SET = await (await fetch('/api/lab/settings')).json();
  const first = R[1] ? 1 : 2;
  QUIET = true;
  if (v.serve_only) {
    SERVE = true;
    document.body.classList.add('serve');
    $('#data h3').textContent = 'Target pH';
    $('#dataHint').textContent = 'Optional. Used by the combined advisory.';
    ['goBtn', 'quality'].forEach(i => { const el = $('#' + i); (el.closest('label') || el).hidden = true; });
    await serveShow(first);
  } else {
    openMode(first, false);
  }
  QUIET = false;
}).catch(() => {});
document.querySelectorAll('.src button').forEach(b => b.addEventListener('click', () => setSrc(b.dataset.s)));

const fi = $('#labFile'), dz = $('#drop');
const setFiles = l => { files = [...l]; $('#dropText').textContent = files.length ? files.map(f => `${f.name} (${Math.round(f.size / 1024)} KB)`).join(', ') : 'Sensor logs: drop .csv or .zip files here, or click to browse'; dz.classList.toggle('has', files.length > 0); };
fi.addEventListener('change', () => setFiles(fi.files));
dz.addEventListener('click', () => fi.click());
['dragover', 'dragenter'].forEach(e => dz.addEventListener(e, ev => { ev.preventDefault(); dz.classList.add('over'); }));
['dragleave', 'drop'].forEach(e => dz.addEventListener(e, ev => { ev.preventDefault(); dz.classList.remove('over'); }));
dz.addEventListener('drop', ev => setFiles(ev.dataTransfer.files));

let cupFile = null;
const cf = $('#cupFile'), cd = $('#cupDrop');
const setCup = f => { cupFile = f || null; $('#cupText').textContent = cupFile ? `${cupFile.name} (${Math.max(1, Math.round(cupFile.size / 1024))} KB)` : 'Cupping scores (optional): drop a .csv file here, or click to browse'; cd.classList.toggle('has', !!cupFile); };
cf.addEventListener('change', () => setCup(cf.files[0]));
cd.addEventListener('click', () => cf.click());
['dragover', 'dragenter'].forEach(e => cd.addEventListener(e, ev => { ev.preventDefault(); cd.classList.add('over'); }));
['dragleave', 'drop'].forEach(e => cd.addEventListener(e, ev => { ev.preventDefault(); cd.classList.remove('over'); }));
cd.addEventListener('drop', ev => setCup(ev.dataTransfer.files[0]));


fetch('/api/lab/settings').then(r => r.json()).then(s => { SET = s; if (mode) renderAdv(); }).catch(() => {});
const kindOf = () => mode === 1 ? 'forecast' : 'cupping';
const fieldOf = k => SET.schema[kindOf()].find(f => f.key === k);
const hint = f => f.hint ? `<small>${f.hint}</small>` : '';
function fieldHTML(f) {
  if (f.type === 'multi') return `<div class="af wide"><span class="al">${f.label}</span><div class="checks">${f.options.map(o => `<label class="ck"><input type="checkbox" data-k="${f.key}" value="${o.v}"> ${o.l}</label>`).join('')}</div>${hint(f)}</div>`;
  if (f.type === 'bool') return `<label class="af ckrow"><input type="checkbox" data-k="${f.key}"><span>${f.label}${hint(f)}</span></label>`;
  if (f.type === 'choice') return `<label class="af"><span class="al">${f.label}</span><select data-k="${f.key}">${f.options.map(o => `<option value="${o.v}">${o.l}</option>`).join('')}</select>${hint(f)}</label>`;
  return `<label class="af"><span class="al">${f.label}</span><input type="number" data-k="${f.key}" min="${f.min}" max="${f.max}" step="${f.step}">${hint(f)}</label>`;
}
function renderAdv() {
  if (!SET || !mode) return;
  const fields = SET.schema[kindOf()], groups = [...new Set(fields.map(f => f.group))];
  $('#advBody').innerHTML = groups.map(g => `<fieldset class="ag"><legend>${g}</legend><div class="afs">${fields.filter(f => f.group === g).map(fieldHTML).join('')}</div></fieldset>`).join('');
  if ($('#quality').value === 'custom') $('#quality').value = 'fast';
  $('#quality').querySelector('[value=custom]').hidden = true;
  fillAdv(SET.presets[kindOf()][$('#quality').value]);
}
function fillAdv(vals) {
  document.querySelectorAll('#advBody [data-k]').forEach(el => {
    const f = fieldOf(el.dataset.k), v = vals[el.dataset.k];
    if (f.type === 'multi') el.checked = (v || []).map(String).includes(el.value);
    else if (f.type === 'bool') el.checked = !!v;
    else el.value = v;
  });
}
function collectAdv() {
  if (!SET || !mode) return {};
  const o = {};
  SET.schema[kindOf()].forEach(f => {
    const els = [...document.querySelectorAll(`#advBody [data-k="${f.key}"]`)];
    if (f.type === 'multi') o[f.key] = els.filter(e => e.checked).map(e => typeof f.options[0].v === 'number' ? +e.value : e.value);
    else if (f.type === 'bool') o[f.key] = els[0].checked;
    else if (f.type === 'choice') o[f.key] = els[0].value;
    else o[f.key] = els[0].value === '' ? f.min : +els[0].value;
  });
  return o;
}
$('#advBody').addEventListener('input', () => { const q = $('#quality'), c = q.querySelector('[value=custom]'); c.hidden = false; q.value = 'custom'; $('#advHint').textContent = 'Custom'; });
$('#quality').addEventListener('change', () => { if (SET && mode && $('#quality').value !== 'custom') { fillAdv(SET.presets[kindOf()][$('#quality').value]); $('#advHint').textContent = ''; } });
$('#advReset').addEventListener('click', () => { const q = $('#quality'); q.value = 'fast'; q.querySelector('[value=custom]').hidden = true; fillAdv(SET.presets[kindOf()].fast); $('#advHint').textContent = ''; });

function settingRows(r) {
  const k = r === R[1] ? 'forecast' : 'cupping';
  const rows = [{parameter: 'Preset', value: {fast: 'Standard', full: 'High Accuracy', custom: 'Custom'}[r.preset] || r.preset}];
  SET.schema[k].forEach(f => {
    const v = r.settings[f.key];
    const val = f.type === 'multi' ? ((v || []).map(x => (f.options.find(o => o.v === x) || {l: x}).l).join(', ') || 'none') : f.type === 'bool' ? (v ? 'yes' : 'no') : f.type === 'choice' ? (f.options.find(o => o.v === v) || {l: v}).l : v;
    rows.push({parameter: f.type === 'multi' ? (f.group.startsWith('Tabular') ? 'Tabular models' : f.group.startsWith('Deep') ? 'Sequence models' : f.label) : f.label, value: val});
  });
  return rows;
}
function mountTabs(root, names, body, after) {
  root.innerHTML = `<div class="chips tabs2">${names.map((t, i) => `<button class="chip${i ? '' : ' on'}" data-k="${t}">${t}</button>`).join('')}</div><div class="tbody"></div>`;
  const show = k => {
    root.querySelector('.tbody').innerHTML = body[k]();
    root.querySelectorAll('.tabs2 .chip').forEach(b => b.classList.toggle('on', b.dataset.k === k));
    if (after) after(k, root);
  };
  root.querySelectorAll('.tabs2 .chip').forEach(b => b.addEventListener('click', () => show(b.dataset.k)));
  show(names[0]);
}

$('#goBtn').addEventListener('click', async () => {
  if (!mode) return;
  const fd = new FormData();
  files.forEach(f => fd.append('files', f));
  if (mode === 2 && cupFile) fd.append('cupping', cupFile);
  fd.append('source', src);
  fd.append('quality', $('#quality').value);
  fd.append('settings', JSON.stringify(collectAdv()));
  const name = mode === 1 ? 'forecast' : 'cupping';
  const r = await fetch(`/api/lab/${name}/train`, {method: 'POST', body: fd});
  if (!r.ok) { alert((await r.json()).error || 'Unable to start training.'); return; }
  $('#goBtn').disabled = true;
  $('#prog').hidden = false;
  $(`#out${mode}`).hidden = true;
  $('#progTitle').textContent = mode === 1 ? 'Training Sensor Forecasting Models' : 'Training Cup Quality Models';
  $('#prog').scrollIntoView({behavior: 'smooth', block: 'center'});
  const m = mode;
  clearInterval(timer);
  timer = setInterval(async () => {
    const s = await (await fetch(`/api/lab/status/${name}`)).json();
    $('#progBar').style.width = s.pct + '%';
    $('#progMsg').textContent = s.state === 'error' ? `Failed: ${s.msg}` : `${s.pct}%: ${s.msg}`;
    if (s.state === 'done' || s.state === 'error') {
      clearInterval(timer);
      $('#goBtn').disabled = false;
      if (s.state === 'done') { R[m] = s.result; setTimeout(() => { $('#prog').hidden = true; m === 1 ? render1() : render2(); }, 600); }
    }
  }, 900);
});

function skills(model) {
  const o = {};
  R[1].detail.filter(d => d.Model === model).forEach(d => { (o[d.Channel] = o[d.Channel] || []).push(d.Skill_persist); });
  return Object.entries(o).map(([c, v]) => [c, v.reduce((a, b) => a + b, 0) / v.length]).sort((a, b) => b[1] - a[1]);
}
const PAL = ['#7A4326', '#46633C', '#C8A27C', '#94452A', '#5B6B8C', '#B08A3E'];

function render1() {
  const r = R[1], sum = r.summary, best = sum.find(x => !BASE.includes(x.Model)), sk = skills(best.Model);
  const f = r.future, last = f.minutes.length - 1;
  $('#out1').hidden = false;
  $('#sum1').innerHTML = `<p class="mu">Trained on ${r.duration_h.toFixed(1)} hours of data (${r.info.windows} windows). Forecasts cover ${Object.keys(NAME).length} channels up to 6 hours ahead.</p><div class="lgrid">
<div class="stat"><span>Best Model</span><b>${best.Model}</b><span>Normalized error ${best.nMAE.toFixed(2)}, lower is better</span></div>
<div class="stat"><span>Skill Versus Naive Forecast</span><b>${pct(best.Skill_persist)}</b><span>Beats the baseline in ${(best.Cells_beat_persist * 100).toFixed(0)}% of forecasts</span></div>
<div class="stat"><span>Most Predictable Channel</span><b>${NAME[sk[0][0]]}</b><span>${pct(sk[0][1])} skill</span></div>
<div class="stat"><span>Least Predictable Channel</span><b>${NAME[sk[sk.length - 1][0]]}</b><span>${pct(sk[sk.length - 1][1])} skill</span></div>
<div class="stat"><span>pH in 6 Hours</span><b>${num('ph', f.ph[last])}</b><span>Current ${num('ph', r.now.ph)}</span></div>
<div class="stat"><span>Process Temperature in 6 Hours</span><b>${num('temp_process', f.temp_process[last])} °C</b><span>Current ${num('temp_process', r.now.temp_process)} °C</span></div></div>
${best.Skill_persist < 0.05 ? '<p class="mu" style="margin-top:12px">The best model only marginally beats the naive baseline. More fermentation runs will improve reliability.</p>' : ''}`;
  $('#viz1').innerHTML = `<p class="mu">Brown: observed. Dashed green: forecast. Red: selected stop time.</p><div class="chips" id="chips"></div><div class="cwrap" id="chart"></div><p style="margin:14px 0 4px"><b>If Fermentation Is Stopped: <span id="stopLbl">Now</span></b></p><input class="lr" type="range" id="stopRange" min="0" max="360" step="10" value="0"><div class="sv" id="stopVals"></div><h3 style="margin:22px 0 4px">Actual vs Predicted</h3><div id="vbt"></div>`;
  $('#stopRange').addEventListener('input', () => { chart(); stopInfo(); });
  drawChips(); chart(); stopInfo();
  r.backtest ? btView($('#vbt'), r.backtest, {model: r.info.best_tab && r.info.best_seq ? 'Ensemble' : (r.info.best_tab || r.info.best_seq), note: 'Validation: every point was predicted by a model that had not seen that part of the log.'}) : $('#vbt').innerHTML = '<p class="mu">Train again to generate this table.</p>';
  detail1(); predPanel(1);
  if (!QUIET) $('#out1').scrollIntoView({behavior: 'smooth'});
}

const approachOf = (m, r) => BASE.includes(m) ? 'Baseline' : m === 'Ensemble' ? 'Ensemble' : ((r.settings || {}).tab_models || []).includes(m) ? 'Tabular' : 'Deep Learning';
const avg = a => a.reduce((x, y) => x + y, 0) / (a.length || 1);

function detail1() {
  const r = R[1], tabs = ['Data', 'Parameters', 'Comparison', 'Training', 'Actual vs Predicted', 'Phases', 'Forecast'], chans = Object.keys(NAME);
  const step = (r.config && r.config.sensor_step_min || 5) / 60;
  const mini = (c, x, y, xl) => `<div class="mini"><b>${NAME[c]}${unitTxt(c)}</b><small>Last ${num(c, y[y.length - 1])} · Min ${num(c, Math.min(...y))} · Max ${num(c, Math.max(...y))}</small>${plot([{x, y, c: '#7A4326', w: 2.2}], 300, 170, xl, '', false, {nx: 5})}</div>`;
  const grid = '<div class="lgrid" style="grid-template-columns:repeat(auto-fit,minmax(260px,1fr))">';
  const dm = r.info.best_tab && r.info.best_seq ? `Ensemble of ${r.info.best_tab} and ${r.info.best_seq}` : (r.info.best_tab || r.info.best_seq);
  const matrix = (key, agg, o) => { const ms = r.summary.map(x => x.Model); return ms.map(m => { const row = {Model: m}; chans.forEach(c => { const v = r.detail.filter(d => d.Model === m && d.Channel === c).map(d => d[key]).filter(isNum); row[NAME[c]] = v.length ? agg(v) : null; }); return row; }); };
  const body = {
    Data: () => `<p class="mu">Last 24 hours after cleaning. Numbers under each title are the latest, lowest and highest values.</p>${grid}${chans.map(c => mini(c, r.history[c].map((_, i) => (i - (r.history[c].length - 1)) * step), r.history[c], 'Hours before now')).join('')}</div>
<h3>Channel Overview (Last 24 Hours)</h3>${tbl(chans.map(c => { const a = r.history[c]; return {channel: c, unit: UNIT[c] || '—', now: r.now[c], min_24h: Math.min(...a), max_24h: Math.max(...a), mean_24h: avg(a)}; }))}
<h3>Data Summary</h3>${tbl([{runs: r.info.runs, duration_h: +r.duration_h.toFixed(1), windows: r.info.windows, tested_windows: r.info.tested}])}
<h3>Data Cleaning</h3><p class="mu">Samples replaced by the glitch filter, per channel.</p>${tbl(Object.entries(r.info.glitches).map(([k, v]) => ({channel: k, samples_replaced: v})))}`,
    Parameters: () => `<h3>Configuration</h3>${tbl(settingRows(r).concat([{parameter: 'Sensor Sampling Step', value: r.config.sensor_step_min + ' min'}]))}`,
    Comparison: () => `<h3>Model Ranking</h3><p class="mu">Normalized error (nMAE), lower is better. Baselines are the naive forecast and a rolling mean.</p>${bars(r.summary, 'Model', 'nMAE')}<div style="height:14px"></div>${tbl(r.summary.map(x => { const {Model, ...rest} = x; return {Model, Approach: approachOf(Model, r), ...rest}; }), {csv: 'model_comparison.csv'})}
<h3>nMAE by Model and Channel</h3><p class="mu">Averaged over all horizons. The lowest value in each column is highlighted.</p>${tbl(matrix('nMAE', avg), {best: 'min'})}
<h3>Skill vs Naive Forecast by Model and Channel</h3><p class="mu">Positive means better than assuming nothing changes.</p>${tbl(matrix('Skill_persist', avg), {pct: true})}
<h3>nMAE by Horizon</h3>${(() => { const hs = [...new Set(r.detail.map(d => d.Horizon_min))].sort((a, b) => a - b), ms = r.summary.map(x => x.Model); const rows = ms.map(m => { const row = {Model: m}; hs.forEach(h => { row[fmtMin(h)] = avg(r.detail.filter(d => d.Model === m && d.Horizon_min === h).map(d => d.nMAE)); }); return row; }); return `${legend(ms.map((m, i) => [m, MPAL[i % 10]]))}${plot(ms.map((m, i) => ({x: hs, y: hs.map(h => avg(r.detail.filter(d => d.Model === m && d.Horizon_min === h).map(d => d.nMAE))), c: MPAL[i % 10], pts: true, dash: BASE.includes(m), tips: hs.map(h => `${m} at ${fmtMin(h)}`)})), 900, 300, 'Forecast horizon (min)', 'nMAE', false, {nx: 7})}<div style="height:10px"></div>${tbl(rows, {best: 'min'})}`; })()}
<h3>Error by Channel and Horizon</h3><div class="row" style="margin:0 0 8px"><label>Model<select id="dm">${[...new Set(r.detail.map(d => d.Model))].map(m => `<option>${m}</option>`).join('')}</select></label></div><div id="dt"></div>`,
    Training: () => `<h3>Validation Protocol</h3><p class="mu">Rolling-origin validation with a purge gap equal to the longest horizon, so no future information reaches training.</p>${tbl([{windows: r.info.windows, tested: r.info.tested, folds: r.info.folds, lookback_min: r.settings.lookback_min, horizons_min: (r.settings.horizons_min || []).join(', '), scheme: r.settings.scheme}])}
<h3>Folds</h3>${r.folds_table ? tbl(r.folds_table) : '<p class="mu">Fold details are saved from the next training run.</p>'}
<h3>Final Models</h3><p class="mu">Refit on all windows after validation.</p>${tbl([{role: 'Best tabular', model: r.info.best_tab || '—'}, {role: 'Best deep learning', model: r.info.best_seq || '—'}, {role: 'Default forecast', model: dm || '—'}])}`,
    'Actual vs Predicted': () => r.backtest ? `<h3>Actual vs Predicted (Validation)</h3><p class="mu">Every point was predicted by a model that had not seen that part of the log. ${r.backtest.time.length} evenly spaced windows are shown.</p><div id="bt1"></div>` : '<p class="mu">This saved result was created before this table existed. Train again to fill it, or use Predict on New Data to compare a file with the trained model.</p>',
    Phases: () => { if (!r.phases.n) return '<p class="mu">Phase detection is unavailable for this run.</p>'; const lb = r.phases.labels, tot = r.phases.segments.reduce((a, s) => a + s.hours, 0), tk = ticks(0, tot, 7), n = lb.length; return `<p class="mu">${r.phases.n} phases found by clustering rolling sensor features.</p>${legend([...new Set(lb)].sort().map(l => [`Phase ${l}`, PAL[l % 6]]))}<svg class="ch" viewBox="0 0 900 62">${lb.map((l, i) => `<rect x="${(14 + i * 872 / n).toFixed(1)}" y="0" width="${(872 / n + 0.6).toFixed(1)}" height="34" fill="${PAL[l % 6]}"/>`).join('')}${tk.t.filter(v => v <= tot).map(v => `<line class="vl" x1="${(14 + v / tot * 872).toFixed(1)}" x2="${(14 + v / tot * 872).toFixed(1)}" y1="34" y2="40"/><text x="${(14 + v / tot * 872).toFixed(1)}" y="54" text-anchor="middle">${v} h</text>`).join('')}</svg>${tbl(r.phases.segments, {csv: 'phases.csv'})}`; },
    Forecast: () => `<h3>Forecast Values</h3><p class="mu">Model: ${esc(dm)}. Forecast from the end of the latest run.</p>${tbl(r.forecast.map(x => { const {horizon_min, forecast_time, ...rest} = x; return {horizon_min, forecast_time, ...rest}; }), {csv: 'forecast_values.csv'})}
<h3>Forecast Curves</h3><p class="mu">Next 6 hours, interpolated between horizons.</p>${grid}${chans.map(c => mini(c, r.future.minutes.map(m => m / 60), r.future[c], 'Hours from now')).join('')}</div>`,
  };
  mountTabs($('#tech1'), tabs, body, (k, root) => {
    const dsel = root.querySelector('#dm');
    if (dsel) { const dt = () => { root.querySelector('#dt').innerHTML = tbl(r.detail.filter(d => d.Model === dsel.value).map(d => ({Channel: d.Channel, Unit: UNIT[d.Channel] || '—', Horizon_min: d.Horizon_min, MAE: d.MAE, RMSE: d.RMSE, nMAE: d.nMAE, Skill_Versus_Naive: d.Skill_persist})), {csv: 'error_by_channel_horizon.csv'}); }; dsel.addEventListener('change', dt); dt(); }
    if (k === 'Actual vs Predicted' && r.backtest) btView(root.querySelector('#bt1'), r.backtest, {model: r.info.best_tab && r.info.best_seq ? 'Ensemble' : (r.info.best_tab || r.info.best_seq)});
  });
}


const bars = (rows, lab, val, fmt = v => v.toFixed(2)) => { const mx = Math.max(...rows.map(x => x[val]), 1e-9); return rows.map(x => `<div class="brow"><span>${esc(x[lab])}</span><div class="bar"><div style="width:${Math.max(2, x[val] / mx * 100)}%"></div></div><b>${fmt(x[val])}</b></div>`).join(''); };
const CPAL = ['#7A4326', '#46633C', '#5B6B8C', '#B08A3E', '#94452A'];
const cls2 = (v, thr) => v >= thr ? 'Acceptable' : 'Below standard';

function detail2() {
  const r = R[2], thr = r.settings.threshold, mae = r.results.map(x => ({Model: x.Model, MAE: x.MAE}));
  const pmodels = Object.keys(r.per_batch[0]).filter(k => !['session', 'actual', 'best_model_error'].includes(k));
  const body = {
    Data: () => `${cupNote(r)}${tbl([{batches: r.n, total_hours: +r.duration_h.toFixed(1), score_min: Math.min(...r.oof.y), score_max: Math.max(...r.oof.y), score_mean: +(avg(r.oof.y)).toFixed(1)}])}
<h3>Batch Overview</h3>${tbl(r.summary, {csv: 'batch_overview.csv'})}
<h3>Sensor Traces</h3><div class="row" style="margin:0 0 8px"><label>Batch<select id="tb">${Object.keys(r.traces).map(k => `<option>${k}</option>`).join('')}</select></label></div><div id="tg" class="lgrid" style="grid-template-columns:repeat(auto-fit,minmax(260px,1fr))"></div>
<h3>Data Cleaning</h3>${tbl(Object.entries(r.glitches).map(([k, v]) => ({channel: k, samples_replaced: v})))}`,
    Parameters: () => `<h3>Configuration</h3>${tbl(settingRows(r))}`,
    Comparison: () => `<h3>Model Ranking</h3><p class="mu">Mean absolute error in score points, lower is better.</p>${bars(mae, 'Model', 'MAE')}<h3>Classification Accuracy</h3><p class="mu">Share of batches correctly rated acceptable or below standard (threshold ${thr}).</p>${bars(r.results.map(x => ({Model: x.Model, A: x.Acc_good})), 'Model', 'A', v => (v * 100).toFixed(0) + '%')}<h3>All Metrics</h3><p class="mu">Cross-validated. “Std” is the spread over repeats.</p>${tbl(r.results, {csv: 'model_comparison.csv'})}`,
    Training: () => `<h3>Validation Protocol</h3><p class="mu">${esc(r.cv)} cross-validation: every batch is scored by a model that never saw it.</p>${tbl([{batches: r.n, validation: r.cv, final_tabular: r.models_fitted.tabular, final_sequence: r.models_fitted.sequence, threshold: thr}])}<h3>Final Models</h3><p class="mu">Refit on all ${r.n} batches after validation. Their predictions are averaged.</p>${tbl([{role: 'Tabular', model: r.models_fitted.tabular || '—'}, {role: 'Sequence (deep learning)', model: r.models_fitted.sequence || '—'}])}`,
    'Actual vs Predicted': () => `<h3>Actual vs Predicted (Validation)</h3><p class="mu">Out-of-fold predictions: each batch was predicted by models that never saw it. Error = predicted − actual, in score points.</p><div class="row" style="margin:0 0 10px"><label>Model<select id="am">${pmodels.map(m => `<option${m === r.best ? ' selected' : ''}>${esc(m)}</option>`).join('')}</select></label></div><div id="ao"></div><h3>All Models Side by Side</h3><p class="mu">Predicted score of every model for each batch.</p>${tbl(r.per_batch.map(x => { const o = {session: x.session, actual: x.actual}; pmodels.forEach(m => { o[m] = x[m]; }); return o; }), {csv: 'all_models_predictions.csv'})}`,
    Importance: () => !r.importance.length ? '<p class="mu">No tabular model was trained.</p>' : `<h3>Most Influential Features</h3><p class="mu">Permutation importance: the error increase when a feature is shuffled.</p>${bars(r.importance.map(x => ({f: x.feature.replace('|', ' '), v: Math.max(0, x.permutation_importance)})), 'f', 'v', v => v.toFixed(3))}<div style="height:14px"></div>${tbl(r.importance, {csv: 'feature_importance.csv'})}`,
    Clusters: () => !r.clusters ? '<p class="mu">Not enough batches to form groups.</p>' : `<h3>Batch Groups</h3><p class="mu">${r.clusters.k} groups found by k-means (silhouette ${r.clusters.silhouette.toFixed(2)}). Axes are the first two principal components.</p><div class="lgrid" style="grid-template-columns:repeat(auto-fit,minmax(300px,1fr))"><div>${legend(r.clusters.summary.map(s => [`Group ${s.cluster}`, CPAL[(s.cluster - 1) % 5]]))}${plot([{x: r.clusters.x, y: r.clusters.y, c: '#7A4326', dots: true, cols: r.clusters.labels.map(l => CPAL[(l - 1) % 5]), labels: r.clusters.ids, tips: r.clusters.ids.map((id, i) => `Batch ${id}: group ${r.clusters.labels[i]}, score ${r.oof.y[i]}`)}], 480, 320, 'Component 1', 'Component 2')}</div><div>${tbl(r.clusters.summary)}</div></div><h3>Batch Assignments</h3>${tbl(r.clusters.ids.map((id, i) => ({session: id, group: r.clusters.labels[i], score: r.oof.y[i]})), {csv: 'batch_groups.csv'})}`,
    Predict: () => `<h3>Final Model Predictions</h3><p class="mu">Final models refit on all ${r.n} batches. These predictions are in-sample and look better than the cross-validated ones. To score new batches, use Predict on New Data.</p>${tbl(r.final.map(x => { const {actual, ...rest} = x; const e = x.Average - actual; return {...rest, Prediction: x.Prediction === 'Good' ? 'Acceptable' : 'Below standard', actual, error: e, abs_error: Math.abs(e)}; }), {csv: 'final_predictions.csv'})}`,
  };
  mountTabs($('#tech2'), Object.keys(body), body, (k, root) => {
    if (k === 'Data') {
      const draw = () => { const t = r.traces[root.querySelector('#tb').value]; root.querySelector('#tg').innerHTML = [['ph', 'pH'], ['co2', 'CO₂'], ['o2', 'O₂'], ['temp_process', 'Process temperature'], ['pressure', 'Pressure']].map(([c, n]) => `<div class="mini"><b>${n}${unitTxt(c)}</b><small>Last ${num(c, t[c][t[c].length - 1])} · Min ${num(c, Math.min(...t[c]))} · Max ${num(c, Math.max(...t[c]))}</small>${plot([{x: t.hours, y: t[c], c: '#7A4326', w: 2.2}], 300, 170, 'Hours', '', false, {nx: 5})}</div>`).join(''); };
      root.querySelector('#tb').addEventListener('change', draw); draw();
    }
    if (k === 'Actual vs Predicted') {
      const draw = () => {
        const m = root.querySelector('#am').value, a = r.per_batch.map(x => x.actual), p = r.per_batch.map(x => x[m]), e = p.map((v, i) => v - a[i]), s = errStats(a, p);
        const ids = r.per_batch.map(x => x.session), tp = a.filter((v, i) => v >= thr && p[i] >= thr).length, fn = a.filter((v, i) => v >= thr && p[i] < thr).length, fp = a.filter((v, i) => v < thr && p[i] >= thr).length, tn = a.filter((v, i) => v < thr && p[i] < thr).length;
        const tips = ids.map((id, i) => `Batch ${id}: actual ${a[i]}, predicted ${p[i].toFixed(2)}, error ${e[i] >= 0 ? '+' : ''}${e[i].toFixed(2)}`);
        root.querySelector('#ao').innerHTML = `${tbl([{batches: s.n, MAE: s.mae, RMSE: s.rmse, bias: s.bias, max_abs_error: s.maxe, R2: s.r2, accuracy: (tp + tn) / s.n}])}
<div class="lgrid" style="grid-template-columns:repeat(auto-fit,minmax(300px,1fr));margin-top:14px"><div>${legend([['Batches', '#7A4326'], ['Perfect prediction', '#8C8C8C']])}${plot([{x: a, y: p, c: '#7A4326', dots: true, labels: ids, tips}], 480, 300, 'Actual score', 'Predicted score', true)}</div><div>${legend([['Over-predicted', '#94452A'], ['Under-predicted', '#5B6B8C']])}${errBars(ids, e, 480, 300)}</div></div>
<h3>Rating Against Threshold ${thr}</h3>${tbl([{actual: 'Acceptable', predicted_acceptable: tp, predicted_below: fn}, {actual: 'Below standard', predicted_acceptable: fp, predicted_below: tn}])}
<h3>Per Batch</h3>${tbl(ids.map((id, i) => ({session: id, actual: a[i], predicted: p[i], error: e[i], abs_error: Math.abs(e[i]), error_pct: e[i] / a[i] * 100, actual_rating: cls2(a[i], thr), predicted_rating: cls2(p[i], thr), correct: (a[i] >= thr) === (p[i] >= thr) ? 'Yes' : 'No'})), {csv: 'actual_vs_predicted.csv'})}`;
      };
      root.querySelector('#am').addEventListener('change', draw); draw();
    }
  });
}

function fileRow(m) {
  return `<div class="row"><label>Sensor Logs<input type="file" class="pf" accept=".csv,.zip" multiple></label>${m === 2 ? '<label>Cupping Scores (Optional)<input type="file" class="pc" accept=".csv"></label>' : `<label>Model<select class="pm">${modelOpts().map(x => `<option value="${esc(x)}">${esc(x)}</option>`).join('')}</select></label>`}<button class="lb pgo">Predict</button></div>`;
}
const modelOpts = () => { const i = R[1].info; return [...new Set([i.best_tab && i.best_seq ? 'Ensemble' : null, i.best_tab, i.best_seq].filter(Boolean))]; };

function predPanel(m) {
  const el = $('#pred' + m);
  if (!el || !R[m]) return;
  el.innerHTML = m === 1
    ? `<h3>Predict on New Data</h3><p class="mu">Upload new sensor logs. The trained model forecasts the next 6 hours from the end of each run.</p>${fileRow(1)}<div class="pres"></div>`
    : `<h3>Predict on New Data</h3><p class="mu">Upload sensor logs of new batches to score them with the trained models.${R[2].info.kind === 'simulated' ? ' This model was trained on simulated data.' : R[2].info.kind !== 'real' ? ' This model was trained with random scores, for testing only.' : ''} Add a cupping file with the real scores to see actual vs predicted and the error.</p>${fileRow(2)}<div class="pres"></div>`;
  const out = el.querySelector('.pres'), go = el.querySelector('.pgo');
  go.addEventListener('click', async () => {
    const f = el.querySelector('.pf').files;
    if (!f.length) { out.innerHTML = '<p class="err">Select sensor log files first.</p>'; return; }
    const fd = new FormData();
    [...f].forEach(x => fd.append('files', x));
    if (m === 1) fd.append('model', el.querySelector('.pm').value);
    else { const c = el.querySelector('.pc').files[0]; if (c) fd.append('cupping', c); }
    out.innerHTML = '<p class="mu">Predicting…</p>';
    go.disabled = true;
    let res, j;
    try { res = await fetch(m === 1 ? '/api/lab/forecast/predict' : '/api/lab/cupping/predict', {method: 'POST', body: fd}); j = await res.json(); }
    catch (e) { res = {ok: false}; j = {error: 'Could not reach the server.'}; }
    go.disabled = false;
    if (!res.ok) { out.innerHTML = `<p class="err">${esc(j.error || 'Prediction failed.')}</p>`; return; }
    m === 1 ? showPred1(out, j) : showPred2(out, j);
  });
}

function showPred1(out, j) {
  const runs = j.runs, step = j.step_min / 60;
  out.innerHTML = `<div class="note"><b>Model used: ${esc(j.model)}</b>Forecasts start at the end of each uploaded run.${j.skipped ? ` ${j.skipped} run(s) were too short and were skipped.` : ''} If this file was part of the training data, the comparison looks better than it will on truly new data.</div>
<div class="row" style="margin:0 0 8px"><label>Run<select class="pr">${runs.map((x, i) => `<option value="${i}">Run ${esc(x.name)}: ${esc(x.start.slice(0, 16))} to ${esc(x.end.slice(0, 16))} (${x.duration_h.toFixed(1)} h)</option>`).join('')}</select></label></div><div class="chips pch"></div><div class="pcw"></div><div class="ptb"></div><h3 style="margin-top:22px">Actual vs Predicted</h3><div class="pbt"></div>`;
  let c = 'ph';
  const draw = () => {
    const x = runs[+out.querySelector('.pr').value], h = x.history[c], n = h.length;
    out.querySelector('.pch').innerHTML = Object.keys(NAME).map(k => `<button class="chip${k === c ? ' on' : ''}" data-c="${k}">${NAME[k]}</button>`).join('');
    out.querySelectorAll('.pch .chip').forEach(b => b.addEventListener('click', () => { c = b.dataset.c; draw(); }));
    out.querySelector('.pcw').innerHTML = `${legend([['Observed', '#7A4326'], ['Forecast', '#46633C']])}${plot([{x: h.map((_, i) => (i - (n - 1)) * step), y: h, c: '#7A4326'}, {x: x.future.minutes.map(m => m / 60), y: x.future[c], c: '#46633C', dash: true, w: 2.6}], 900, 300, 'Hours from the end of the run', NAME[c] + unitTxt(c), false, {vlines: [{x: 0, label: 'End of run'}], nx: 9})}`;
    out.querySelector('.ptb').innerHTML = `<h3>Forecast Values</h3>${tbl(x.forecast.map(f => { const {horizon_min, forecast_time, ...rest} = f; return {horizon_min, forecast_time, ...rest}; }), {csv: 'new_data_forecast.csv'})}`;
  };
  out.querySelector('.pr').addEventListener('change', draw);
  draw();
  const bt = out.querySelector('.pbt');
  if (j.backtest) btView(bt, j.backtest, {model: j.model, note: `${j.backtest.windows} windows in the file have a known future and were compared; ${j.backtest.time.length} evenly spaced ones are shown.`});
  else bt.innerHTML = `<p class="mu">${esc(j.backtest_note || 'No comparison available.')}</p>`;
}

function showPred2(out, j) {
  const P = j.predictions, thr = j.threshold, hasA = P.some(x => isNum(x.actual)), avgM = (j.metrics || []).find(x => x.model === 'Average');
  const acc = P.filter(x => x.Average >= thr).length;
  const rows = P.map(x => ({...x, Prediction: x.Prediction === 'Good' ? 'Acceptable' : 'Below standard'}));
  const test = j.kind && j.kind !== 'real' ? '<div class="note test"><b>Model Trained in Test Mode</b>Scores are for testing only.</div>' : '';
  const ids = P.filter(x => isNum(x.actual)).map(x => x.session), a = P.filter(x => isNum(x.actual)).map(x => x.actual), p = P.filter(x => isNum(x.actual)).map(x => x.Average), e = p.map((v, i) => v - a[i]);
  out.innerHTML = `${test}${(j.notes || []).map(n => `<div class="note test">${esc(n)}</div>`).join('')}<div class="lgrid" style="margin:12px 0"><div class="stat"><span>Batches Scored</span><b>${P.length}</b><span>${acc} acceptable, ${P.length - acc} below standard</span></div><div class="stat"><span>Mean Predicted Score</span><b>${avg(P.map(x => x.Average)).toFixed(1)}</b><span>Threshold ${thr}</span></div>${avgM ? `<div class="stat"><span>Mean Absolute Error</span><b>${avgM.MAE.toFixed(2)} pts</b><span>${avgM.batches} batches with real scores</span></div><div class="stat"><span>Rating Accuracy</span><b>${(avgM.accuracy * 100).toFixed(0)}%</b><span>RMSE ${avgM.RMSE.toFixed(2)}, bias ${avgM.bias >= 0 ? '+' : ''}${avgM.bias.toFixed(2)}</span></div>` : ''}</div>
<h3>Predicted Scores</h3><p class="mu">${hasA ? 'Error = predicted (average of both models) − actual, in score points.' : 'Add a cupping file with the real scores to see actual vs predicted and the error.'}</p>${tbl(rows, {csv: 'new_batch_predictions.csv'})}
${hasA ? `<h3>Actual vs Predicted</h3><div class="lgrid" style="grid-template-columns:repeat(auto-fit,minmax(300px,1fr))"><div>${legend([['Batches', '#7A4326'], ['Perfect prediction', '#8C8C8C']])}${plot([{x: a, y: p, c: '#7A4326', dots: true, labels: ids, tips: ids.map((id, i) => `Batch ${id}: actual ${a[i]}, predicted ${p[i].toFixed(2)}`)}], 480, 300, 'Actual score', 'Predicted score', true)}</div><div>${legend([['Over-predicted', '#94452A'], ['Under-predicted', '#5B6B8C']])}${errBars(ids, e, 480, 300)}</div></div><h3>Error by Model</h3>${tbl(j.metrics)}` : ''}
<h3>Batch Overview</h3>${tbl(j.batches)}`;
}

function drawChips() {
  $('#chips').innerHTML = Object.keys(NAME).map(c => `<button class='chip${c === cur ? ' on' : ''}' data-c='${c}'>${NAME[c]}</button>`).join('');
  document.querySelectorAll('#chips .chip').forEach(el => el.addEventListener('click', () => { cur = el.dataset.c; drawChips(); chart(); stopInfo(); }));
}
const stopIdx = () => Math.round(parseInt($('#stopRange').value, 10) / 10);

function chart() {
  const h = R[1].history, f = R[1].future, n = h.t.length, y = h[cur], fy = f[cur];
  const all = y.concat(fy), lo = Math.min(...all), hi = Math.max(...all), pad = (hi - lo || 1) * 0.12;
  const W = 720, Hh = 280, l = 54, r = 14, t = 12, b = 30, tot = n + 72;
  const X = i => l + (W - l - r) * i / tot, Y = v => t + (Hh - t - b) * (1 - (v - (lo - pad)) / (hi - lo + 2 * pad));
  const pts = y.map((v, i) => `${X(i).toFixed(1)},${Y(v).toFixed(1)}`).join(' ');
  const fp = fy.map((v, i) => `${X(n - 1 + i * 2).toFixed(1)},${Y(v).toFixed(1)}`).join(' ');
  let g = '';
  for (let k = 0; k <= 4; k++) { const v = lo - pad + (hi - lo + 2 * pad) * k / 4; g += `<line x1='${l}' x2='${W - r}' y1='${Y(v)}' y2='${Y(v)}' stroke='var(--line)'/><text x='${l - 6}' y='${Y(v) + 4}' text-anchor='end'>${v.toFixed(Math.abs(v) > 100 ? 0 : 2)}</text>`; }
  const sx = X(n - 1 + stopIdx() * 2);
  $('#chart').innerHTML = `<svg viewBox='0 0 ${W} ${Hh}' width='100%'>${g}<line x1='${X(n - 1)}' x2='${X(n - 1)}' y1='${t}' y2='${Hh - b}' stroke='var(--muted)' stroke-dasharray='3 3'/><text x='${X(n - 1)}' y='${Hh - 10}' text-anchor='middle'>Now</text><text x='${l}' y='${Hh - 10}'>24 h ago</text><text x='${W - r}' y='${Hh - 10}' text-anchor='end'>+6 h</text><polyline points='${pts}' fill='none' stroke='var(--accent)' stroke-width='2.4'/><polyline points='${fp}' fill='none' stroke='var(--good)' stroke-width='2.6' stroke-dasharray='6 5'/><line x1='${sx}' x2='${sx}' y1='${t}' y2='${Hh - b}' stroke='var(--poor)' stroke-width='2'/><circle id='dot' r='4.5' fill='var(--ink)' visibility='hidden'/></svg><div class='tip' id='tip' hidden></div>`;
  const svg = $('#chart svg'), dot = $('#dot'), tip = $('#tip');
  svg.addEventListener('pointermove', ev => {
    const bb = svg.getBoundingClientRect(), px = (ev.clientX - bb.left) / bb.width * W;
    const i = Math.max(0, Math.min(tot - 1, Math.round((px - l) / (W - l - r) * tot))), fut = i >= n;
    const v = fut ? fy[Math.min(fy.length - 1, Math.round((i - n + 1) / 2))] : y[i];
    dot.setAttribute('cx', X(i)); dot.setAttribute('cy', Y(v)); dot.setAttribute('visibility', 'visible');
    tip.hidden = false; tip.style.left = `${X(i) / W * bb.width}px`; tip.style.top = `${Y(v) / Hh * bb.height}px`;
    tip.textContent = `${fut ? 'In ' + fmtMin((i - n + 1) * 5) : fmtMin((n - 1 - i) * 5) + ' ago'}: ${num(cur, v)} ${UNIT[cur]}${fut ? ' (forecast)' : ''}`;
  });
  svg.addEventListener('pointerleave', () => { dot.setAttribute('visibility', 'hidden'); tip.hidden = true; });
}
function stopInfo() {
  const i = stopIdx(), f = R[1].future;
  $('#stopLbl').textContent = i === 0 ? 'Now' : `in ${fmtMin(i * 10)}`;
  $('#stopVals').innerHTML = ['ph', 'co2', 'o2', 'temp_process'].map(c => `<div>${NAME[c]}<b>${num(c, f[c][i])}</b>${UNIT[c]}</div>`).join('');
}

function ticks(lo, hi, n = 5) {
  if (!(hi > lo)) { lo -= 0.5; hi += 0.5; }
  const raw = (hi - lo) / (n - 1), mag = Math.pow(10, Math.floor(Math.log10(raw))), f = raw / mag;
  const step = (f < 1.5 ? 1 : f < 3 ? 2 : f < 7 ? 5 : 10) * mag, t = [];
  for (let v = Math.floor(lo / step + 1e-9) * step; v <= Math.ceil(hi / step - 1e-9) * step + step / 2; v += step) t.push(+v.toFixed(10));
  return {t, step};
}
const tf = step => { const d = Math.max(0, Math.min(4, Math.ceil(-Math.log10(step) - 1e-9))); return v => v.toFixed(d); };
const MPAL = ['#7A4326', '#46633C', '#5B6B8C', '#B08A3E', '#94452A', '#4F8A8B', '#8A5A83', '#6B7F3B', '#8C8C8C', '#C8A27C'];
const legend = items => `<div class="leg2">${items.map(([n, c]) => `<span><i style="background:${c}"></i>${esc(n)}</span>`).join('')}</div>`;

function plot(series, W, H, xl, yl, ref, o = {}) {
  const xs = series.flatMap(s => s.x), ys = series.flatMap(s => s.y).filter(isNum);
  if (!xs.length || !ys.length) return '<p class="mu">No data available.</p>';
  let x0 = Math.min(...xs), x1 = Math.max(...xs), y0 = Math.min(...ys), y1 = Math.max(...ys);
  if (ref) { x0 = y0 = Math.min(x0, y0); x1 = y1 = Math.max(x1, y1); }
  const py = (y1 - y0 || 1) * 0.06, px = ref ? (x1 - x0 || 1) * 0.06 : 0;
  const xt = ticks(x0 - px, x1 + px, o.nx || 6), yt = ticks(y0 - py, y1 + py, 5);
  const X0 = xt.t[0], X1 = xt.t[xt.t.length - 1], Y0 = yt.t[0], Y1 = yt.t[yt.t.length - 1];
  const L = 58, R = 14, T = 20, B = 38;
  const X = v => L + (W - L - R) * (v - X0) / (X1 - X0 || 1), Y = v => T + (H - T - B) * (1 - (v - Y0) / (Y1 - Y0 || 1));
  const xf = tf(xt.step), yf = tf(yt.step), r1 = v => v.toFixed(1);
  let g = '';
  yt.t.forEach(v => { g += `<line class="gl" x1="${L}" x2="${W - R}" y1="${r1(Y(v))}" y2="${r1(Y(v))}"/><text x="${L - 7}" y="${r1(Y(v) + 4)}" text-anchor="end">${yf(v)}</text>`; });
  xt.t.forEach(v => { g += `<line class="gl" y1="${T}" y2="${H - B}" x1="${r1(X(v))}" x2="${r1(X(v))}"/><text x="${r1(X(v))}" y="${H - B + 16}" text-anchor="middle">${xf(v)}</text>`; });
  if (ref) g += `<line x1="${X(X0)}" y1="${Y(Y0)}" x2="${X(X1)}" y2="${Y(Y1)}" stroke="var(--muted)" stroke-dasharray="5 4"/>`;
  (o.vlines || []).forEach(v => { g += `<line class="vl" x1="${X(v.x)}" x2="${X(v.x)}" y1="${T}" y2="${H - B}"/><text x="${X(v.x)}" y="${T - 6}" text-anchor="middle">${esc(v.label)}</text>`; });
  let body = '';
  series.forEach(s => {
    const tip = i => s.tips && s.tips[i] ? `<title>${esc(s.tips[i])}</title>` : '';
    if (s.dots) body += s.x.map((v, i) => isNum(s.y[i]) ? `<circle cx="${r1(X(v))}" cy="${r1(Y(s.y[i]))}" r="5" fill="${(s.cols && s.cols[i]) || s.c}" fill-opacity=".8" stroke="var(--surface)" stroke-width="1">${tip(i)}</circle>` : '').join('');
    else {
      const pts = s.x.map((v, i) => isNum(s.y[i]) ? `${r1(X(v))},${r1(Y(s.y[i]))}` : null).filter(Boolean).join(' ');
      body += `<polyline fill="none" stroke="${s.c}" stroke-width="${s.w || 2.4}" stroke-linejoin="round"${s.dash ? ' stroke-dasharray="6 5"' : ''} points="${pts}"/>`;
      if (s.pts) body += s.x.map((v, i) => isNum(s.y[i]) ? `<circle cx="${r1(X(v))}" cy="${r1(Y(s.y[i]))}" r="3" fill="${s.c}">${tip(i)}</circle>` : '').join('');
    }
    if (s.labels) body += s.x.map((v, i) => isNum(s.y[i]) ? `<text class="pt" x="${r1(X(v) + 7)}" y="${r1(Y(s.y[i]) - 6)}">${esc(s.labels[i])}</text>` : '').join('');
  });
  return `<svg class="ch" viewBox="0 0 ${W} ${H}" role="img"><text x="${L - 50}" y="12" text-anchor="start">${esc(yl)}</text>${g}${body}<text x="${(L + W - R) / 2}" y="${H - 4}" text-anchor="middle">${esc(xl)}</text></svg>`;
}

function errBars(ids, errs, W = 640, H = 250, yl = 'Error (predicted − actual)') {
  const mx = Math.max(...errs.map(Math.abs), 1e-9), yt = ticks(-mx * 1.15, mx * 1.15, 5), Y0 = yt.t[0], Y1 = yt.t[yt.t.length - 1];
  const L = 58, R = 14, T = 20, B = 36, n = ids.length, bw = Math.min(34, (W - L - R) / n * 0.68);
  const Y = v => T + (H - T - B) * (1 - (v - Y0) / (Y1 - Y0)), X = i => L + (W - L - R) * (i + 0.5) / n, yf = tf(yt.step);
  let g = yt.t.map(v => `<line class="gl" x1="${L}" x2="${W - R}" y1="${Y(v).toFixed(1)}" y2="${Y(v).toFixed(1)}"/><text x="${L - 7}" y="${(Y(v) + 4).toFixed(1)}" text-anchor="end">${yf(v)}</text>`).join('');
  g += `<line class="zl" x1="${L}" x2="${W - R}" y1="${Y(0)}" y2="${Y(0)}"/>`;
  const skip = Math.ceil(n / 24);
  const body = errs.map((e, i) => `<rect x="${(X(i) - bw / 2).toFixed(1)}" y="${Math.min(Y(0), Y(e)).toFixed(1)}" width="${bw.toFixed(1)}" height="${Math.max(1, Math.abs(Y(e) - Y(0))).toFixed(1)}" rx="2" fill="${e > 0 ? '#94452A' : '#5B6B8C'}" fill-opacity=".85"><title>${esc(ids[i])}: ${e >= 0 ? '+' : ''}${e.toFixed(2)}</title></rect>${n <= 16 ? `<text class="pt" x="${X(i).toFixed(1)}" y="${(e >= 0 ? Y(e) - 4 : Y(e) + 12).toFixed(1)}" text-anchor="middle">${e >= 0 ? '+' : ''}${e.toFixed(1)}</text>` : ''}${i % skip === 0 ? `<text x="${X(i).toFixed(1)}" y="${H - B + 16}" text-anchor="middle">${esc(ids[i])}</text>` : ''}`).join('');
  return `<svg class="ch" viewBox="0 0 ${W} ${H}" role="img"><text x="4" y="12">${esc(yl)}</text>${g}${body}<text x="${(L + W - R) / 2}" y="${H - 4}" text-anchor="middle">Batch (session)</text></svg>`;
}

function errStats(a, p) {
  const n = a.length, e = p.map((v, i) => v - a[i]), sum = x => x.reduce((s, v) => s + v, 0);
  const m = sum(a) / n, sst = sum(a.map(v => (v - m) ** 2)), sse = sum(e.map(v => v * v));
  return {n, mae: sum(e.map(Math.abs)) / n, rmse: Math.sqrt(sse / n), bias: sum(e) / n, maxe: Math.max(...e.map(Math.abs)), r2: n > 1 && sst > 1e-12 ? 1 - sse / sst : null};
}
const addMin = (s, m) => { const d = new Date(s.replace(' ', 'T').slice(0, 16) + ':00Z'); d.setUTCMinutes(d.getUTCMinutes() + m); const p = n => String(n).padStart(2, '0'); return `${d.getUTCFullYear()}-${p(d.getUTCMonth() + 1)}-${p(d.getUTCDate())} ${p(d.getUTCHours())}:${p(d.getUTCMinutes())}`; };
const unitTxt = c => UNIT[c] ? ` (${UNIT[c]})` : '';

function btView(root, bt, opt = {}) {
  const models = Object.keys(bt.pred), def = models.includes(opt.model) ? opt.model : (models.find(m => m !== 'Persistence') || models[0]);
  const optsHtml = (list, sel) => list.map(([v, l]) => `<option value="${esc(v)}"${String(v) === String(sel) ? ' selected' : ''}>${esc(l)}</option>`).join('');
  root.innerHTML = `${opt.note ? `<p class="mu">${opt.note}</p>` : ''}<div class="row" style="margin:0 0 12px"><label>Model<select class="bm">${optsHtml(models.map(m => [m, m]), def)}</select></label><label>Channel<select class="bc">${optsHtml(bt.channels.map((c, i) => [i, NAME[c] + unitTxt(c)]), 0)}</select></label><label>Horizon<select class="bh">${optsHtml(bt.horizons.map((h, i) => [i, fmtMin(h)]), 0)}</select></label></div><div class="bo"></div>`;
  const out = root.querySelector('.bo'), val = c => root.querySelector(c).value, W = bt.time.length;
  const draw = () => {
    const m = val('.bm'), c = +val('.bc'), hi = +val('.bh'), ch = bt.channels[c];
    const A = (w, h) => bt.actual[w][c][h], P = (mm, w, h) => bt.pred[mm][w][c][h];
    const ok = h => [...Array(W).keys()].filter(w => isNum(A(w, h)) && isNum(P(m, w, h)));
    const hrows = bt.horizons.map((h, i) => {
      const ws = ok(i), a = ws.map(w => A(w, i)), s = ws.length ? errStats(a, ws.map(w => P(m, w, i))) : null;
      const row = {horizon_min: h, windows: ws.length, MAE: s && s.mae, RMSE: s && s.rmse, bias: s && s.bias, max_abs_error: s && s.maxe};
      if (m !== 'Persistence' && bt.pred.Persistence) { const sp = ws.length ? errStats(a, ws.map(w => P('Persistence', w, i))) : null; row.persistence_MAE = sp && sp.mae; row.skill_vs_persistence = s && sp ? 1 - s.mae / Math.max(sp.mae, 1e-12) : null; }
      return row;
    });
    const ws = ok(hi), rows = ws.map(w => { const a = A(w, hi), p = P(m, w, hi), e = p - a; return {origin_time: bt.time[w], forecast_time: addMin(bt.time[w], bt.horizons[hi]), actual: a, predicted: p, error: e, abs_error: Math.abs(e), error_pct: Math.abs(a) > 1e-9 ? e / Math.abs(a) * 100 : null}; });
    const all = () => { const o = []; bt.channels.forEach((cc, ci) => bt.horizons.forEach((h, i) => { for (let w = 0; w < W; w++) { const a = bt.actual[w][ci][i], p = bt.pred[m][w][ci][i]; if (isNum(a) && isNum(p)) o.push({channel: NAME[cc], horizon_min: h, origin_time: bt.time[w], forecast_time: addMin(bt.time[w], h), actual: a, predicted: p, error: p - a, abs_error: Math.abs(p - a)}); } })); return o; };
    const tip = r => `${r.forecast_time}: actual ${r.actual.toFixed(3)}, predicted ${r.predicted.toFixed(3)}, error ${r.error >= 0 ? '+' : ''}${r.error.toFixed(3)}`;
    const idx = rows.map((_, i) => i + 1), tips = rows.map(tip), yl = NAME[ch] + unitTxt(ch);
    out.innerHTML = `<h3>Error by Horizon</h3><p class="mu">${esc(NAME[ch])}, ${esc(m)}. Errors are in ${UNIT[ch] ? esc(UNIT[ch]) : 'sensor units'}; error = predicted − actual.</p>${tbl(hrows)}
<h3>Actual vs Predicted at ${fmtMin(bt.horizons[hi])} Ahead</h3>${ws.length ? `<div class="lgrid" style="grid-template-columns:repeat(auto-fit,minmax(300px,1fr))"><div>${legend([['Actual', '#7A4326'], ['Predicted', '#46633C']])}${plot([{x: idx, y: rows.map(r => r.actual), c: '#7A4326', pts: true, tips}, {x: idx, y: rows.map(r => r.predicted), c: '#46633C', dash: true, pts: true, tips}], 480, 280, 'Window (time order)', yl, false, {nx: 7})}</div><div>${legend([['Windows', '#7A4326'], ['Perfect prediction', '#8C8C8C']])}${plot([{x: rows.map(r => r.actual), y: rows.map(r => r.predicted), c: '#7A4326', dots: true, tips}], 480, 280, 'Actual', 'Predicted', true)}</div></div>` : '<p class="mu">No windows available.</p>'}
<h3>Actual, Predicted and Error</h3>${tbl(rows, {csv: 'actual_vs_predicted.csv', all})}`;
  };
  ['.bm', '.bc', '.bh'].forEach(s => root.querySelector(s).addEventListener('change', draw));
  draw();
}

const KIND = {real: ['Real Cupping Scores', false], simulated: ['Simulated Sample Data', true], pseudo: ['Test Mode: Pseudo Batches with Random Scores', true], random: ['Test Mode: Random Scores', true]};
function cupNote(r) {
  const i = r.info || {kind: 'real', notes: []}, [title, test] = KIND[i.kind] || KIND.real;
  const lines = (i.notes || []).map(n => `<li>${n}</li>`).join('');
  return `<div class="note${test ? ' test' : ''}"><b>${title}</b>${i.kind === 'real' ? `${i.n_used} scored batches used.` : ''}${lines ? `<ul>${lines}</ul>` : ''}</div>`;
}

function render2() {
  const r = R[2], b = r.results.find(x => x.Model === r.best) || r.results[0], tops = r.importance.slice(0, 3).map(x => x.feature.replace('|', ' ')).join(', ');
  $('#out2').hidden = false;
  $('#sum2').innerHTML = `${cupNote(r)}<p class="mu">Trained on ${r.n} batches with ${r.cv} validation.</p><div class="lgrid">
<div class="stat"><span>Best Model</span><b>${r.best}</b><span>${b.Approach}</span></div>
<div class="stat"><span>Mean Absolute Error</span><b>${b.MAE.toFixed(2)} pts</b><span>RMSE ${b.RMSE.toFixed(2)}</span></div>
<div class="stat"><span>Classification Accuracy</span><b>${(b.Acc_good * 100).toFixed(0)}%</b><span>Acceptable or below standard, threshold ${r.settings.threshold}</span></div>
<div class="stat"><span>Most Influential Factors</span><b style="font-size:16px">${tops || 'None'}</b><span>By permutation importance</span></div></div>
${r.n < 15 ? '<p class="mu" style="margin-top:12px">Few batches, so results are noisy. Twenty or more are recommended.</p>' : ''}`;
  const pb = r.per_batch, bm = r.best, tip = pb.map(x => `Batch ${x.session}: actual ${x.actual}, predicted ${x[bm].toFixed(2)}`);
  $('#viz2').innerHTML = `<p class="mu">Left: actual versus predicted score of the best model (${esc(bm)}), closer to the dashed line is better. Right: mean absolute error by model.</p><div class="lgrid" style="grid-template-columns:repeat(auto-fit,minmax(300px,1fr))"><div>${plot([{x: pb.map(x => x.actual), y: pb.map(x => x[bm]), c: '#7A4326', dots: true, labels: pb.map(x => x.session), tips: tip}], 480, 300, 'Actual Score', 'Predicted Score', true)}</div><div>${bars(r.results.map(x => ({Model: x.Model, MAE: x.MAE})), 'Model', 'MAE')}</div></div><h3 style=\"margin:22px 0 4px\">Actual vs Predicted (${esc(bm)})</h3><p class=\"mu\">Cross-validated. Error = predicted − actual, in score points.</p>${tbl(pb.map(x => ({session: x.session, actual: x.actual, predicted: x[bm], error: x[bm] - x.actual, abs_error: Math.abs(x[bm] - x.actual), error_pct: (x[bm] - x.actual) / x.actual * 100})), {csv: 'actual_vs_predicted.csv'})}`;
  detail2(); predPanel(2);
  if (!QUIET) $('#out2').scrollIntoView({behavior: 'smooth'});
}

document.querySelectorAll('[data-t]').forEach(b => b.addEventListener('click', () => {
  const el = $('#' + b.dataset.t), on = el.hidden;
  el.hidden = !on;
  b.textContent = b.textContent.replace(on ? 'Show' : 'Hide', on ? 'Hide' : 'Show');
}));

document.querySelectorAll('[data-merge]').forEach(b => b.addEventListener('click', async () => {
  const out = $('#mergeOut'), fd = new FormData(), tp = $('#tph').value;
  if (tp) fd.append('target_ph', tp);
  out.hidden = false; out.className = 'lc adv';
  out.innerHTML = '<h3>Combining Models</h3><div class="bar"><div style="width:100%"></div></div>';
  let r, j;
  try {
    r = await fetch('/api/lab/merge', {method: 'POST', body: fd});
    const txt = await r.text();
    try { j = JSON.parse(txt); } catch (e) { j = {error: `Server returned ${r.status}: ${txt.slice(0, 200) || 'empty response'}`}; }
  } catch (e) {
    r = {ok: false};
    j = {error: 'Could not reach the server. It may have run out of memory and restarted.'};
  }
  if (!r.ok) { out.innerHTML = `<h3>Models Cannot Be Combined Yet</h3><p class="err">${j.error}</p>`; out.scrollIntoView({behavior: 'smooth'}); return; }
  out.classList.add('good');
  const testNote = j.cup_kind && j.cup_kind !== 'real' ? '<div class="note test"><b>Cup Quality Model Trained in Test Mode</b>Scores and the stop time are for testing only.</div>' : '';
  const a = j.advice, i = a.best_min / 10, f = j.future;
  out.innerHTML = `<h3>Combined Advisory</h3>${testNote}<div class="big" style="font:600 22px var(--serif);margin:6px 0">Recommended Stop Time: in about ${fmtMin(a.best_min)}, predicted score ${a.best_score.toFixed(1)} (${a.best_score >= 80 ? 'acceptable' : 'below standard'})</div><p class="mu">Forecast at that time: pH ${num('ph', f.ph[i])}, CO₂ ${num('co2', f.co2[i])} ppm, process temperature ${num('temp_process', f.temp_process[i])} °C. The estimate is reliable only when the current duration is close to that of the Mode 2 training batches.</p>${plot([{x: f.minutes.slice(1).map(m => m / 60), y: a.scores, c: '#46633C'}], 900, 280, 'Hours From Now if Fermentation Is Stopped', 'Predicted Cupping Score')}`;
  out.scrollIntoView({behavior: 'smooth'});
}));
})();
